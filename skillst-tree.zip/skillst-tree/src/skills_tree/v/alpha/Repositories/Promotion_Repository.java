/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha.Repositories;

import skills_tree.v.alpha.Models.Promotion;

/**
 *
 * @author Jamal-Jcyber
 */
public interface Promotion_Repository {

    public int create_NewPromotion(Promotion p);

    public int update_Promotion(int _id);

    public int delete_Promotion(int id_);

    public void display_All_Promotions();
}
