/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha;

import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import skills_tree.v.alpha.Models.Administrator;
import skills_tree.v.alpha.Models.Apprenant;
import skills_tree.v.alpha.Models.Competence;
import skills_tree.v.alpha.Models.DBA.SingletonConnection;
import skills_tree.v.alpha.Models.Enums.Category;
import skills_tree.v.alpha.Models.Enums.Duration;
import skills_tree.v.alpha.Models.Enums.Sensitive;
import skills_tree.v.alpha.Models.Enums.Role;
import skills_tree.v.alpha.Models.Level;
import skills_tree.v.alpha.Models.Person;
import skills_tree.v.alpha.Models.Promotion;
import skills_tree.v.alpha.Models.Reference;
import skills_tree.v.alpha.Models.Staff;
import skills_tree.v.alpha.Services.Person_ServiceImpl;

/**
 *
 * @author Jamal-Jcyber
 */
public class Authen_AuthorController implements Initializable {
	SingletonConnection jdbc = SingletonConnection.getInstance();
	LinkedList<Person> _listsPersons = null;
	LinkedList<Promotion> _listsPromotions = null;

	@FXML
	private Label label;
	@FXML
	private Button button;
	@FXML
	private Button button1;
	@FXML
	private TextField matricule_textfieldInput;
	@FXML
	private PasswordField password_textfieldInput;
	@FXML
	private ComboBox<Role> type_RoleComboBox;
	@FXML
	private Button Login_button;
	@FXML
	private Button button2;
	@FXML
	private Button button11;
	@FXML
	private TextField id_PersonInput;
	@FXML
	private Button update_Button;
	@FXML
	private Button button111;
	@FXML
	private Button button1111;

	@FXML
	private void handleButtonAction(ActionEvent event) {
		System.out.println("You clicked me!");
		label.setText("Hello World!");
		try {
			_listsPersons = jdbc.get_All_PersonsContents();
			Iterator<Person> iterator = _listsPersons.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		// TODO
		type_RoleComboBox.setItems(FXCollections.observableArrayList(Role.values()));
	}

	@FXML
	private void handleButton1Action(ActionEvent event) throws SQLException {
		System.out.println("You clicked me!!");
		label.setText("Hello World!!");
		try {
			Person p = new Staff("Hanae El Wahaby", "0612554890", "nai@Sihfdmplon.com", "ae_jhdfutylV1", "root_1", Role.STAFF, 1);
			int status = jdbc.sign_UpPersonMethod(p);
			if (status > 0) {
				System.out.println("Data was Inserted Successfully With The ID :" + p.getId_Person());
			} else {
				System.out.println("Data != Inserted :( Sorry");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@FXML
	private void handleLoginButton(ActionEvent event) throws SQLException {
		if (matricule_textfieldInput.getText().trim().isEmpty() || password_textfieldInput.getText().trim().isEmpty() || type_RoleComboBox.getValue() == null) {
			label.setText("All Fields Are Required");
		} else {
			System.out.println(matricule_textfieldInput.getText());
			System.out.println(password_textfieldInput.getText());
			System.out.println(type_RoleComboBox.getValue());
			Person person = jdbc.sign_InPersonBasedOnHisType(matricule_textfieldInput.getText(), password_textfieldInput.getText(), type_RoleComboBox.getValue());
			System.out.println(person);
			if (person != null) {
				// code goes here 
				if (person.getRole().equals(Role.ADMINISTRATOR)) {
					// REDIRECTION ADMINISTRATOR BOARD
					System.out.println("Administrator Dashboard");

				} else if (person.getRole().equals(Role.STAFF)) {
					// REDIRECTION STAFF BOARD
					System.out.println("Staff Dashboard");
				} else {
					// REDIRECTION APPRENANT BOARD
					System.out.println("Apprenant Dashboard");

				}

			} else {
				System.out.println("No Person Was Found ::(( ");
			}
		}
	}

	@FXML
	private void handleButton2Action(ActionEvent event) {
		try {
			_listsPromotions = jdbc.get_All_PromotionsContents();
			Iterator<Promotion> iterator = _listsPromotions.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@FXML
	private void handleButton11Action(ActionEvent event) {
		try {
			Promotion promotion = new Promotion("Alan Turing", LocalDate.now(), Category.FIRST_YEAR, "WEB DEVLOPPER Referencial ...");
			int state = jdbc.create_NewPromotion(promotion);
			if (state > 0) {
				System.out.println("Promotion Was Created Successfully :)");
			} else {
				System.out.println("Promotion != Created Successfully :(");
			}
		} catch (SQLException e) {
		}
	}

	@FXML
	private void handleButtonUpdateAction(ActionEvent event) {
		try {
			Promotion p = jdbc._getOneByID(1);
			p.setTitle("New Title");
			p.setDate_Creation(LocalDate.now());
			p.setCategory_OfPromotion(Category.SECOND_YEAR);
			p.setDescription("Just a Description");
			int state = jdbc.update_Promotion(p);
			if (state > 0) {
				System.out.println("Promotion Was Updated Successfully :)");
			} else {
				System.out.println("Promotion != Updated Successfully :(");
			}
		} catch (SQLException e) {
		}
	}

	@FXML
	private void handleButton111Action(ActionEvent event) {
		try {
			Reference reference = new Reference("WEB & MOBILE Conceptor", 1, Duration.ZERO_YEAR, true);
			int state = jdbc.create_Referencial(reference);

			if (state > 0) {
				System.out.println("Referencial Was Created Successfully :)");
			} else {
				System.out.println("Referencial != Created Successfully :(");
			}
		} catch (SQLException e) {
		}
	}

	@FXML
	private void handleButton1111Action(ActionEvent event) {
		try {
			Competence competence = new Competence(1, true, "Create mock-ups for an application");
			int state = jdbc.create_Competence(competence);

			if (state > 0) {
				System.out.println("Competence Was Created Successfully :)");
			} else {
				System.out.println("Competence != Created Successfully :(");
			}
		} catch (SQLException e) {
		}
	}

	@FXML
	private void handleButton11111Action(ActionEvent event) {
		try {
			Level level = new Level(1, Sensitive.EASY, true, true, true, true, true);
			int state = jdbc.create_CustomCompetenceWithLevels(level);
			if (state > 0) {
				System.out.println("Competence With Custom Level Was Created Successfully :)");
			} else {
				System.out.println("Competence With Custom Level != Created Successfully :(");
			}
		} catch (SQLException e) {
		}
	}

}















