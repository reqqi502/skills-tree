/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import skills_tree.v.alpha.Models.DBA.SingletonConnection;
import skills_tree.v.alpha.Models.Enums.Role;
import skills_tree.v.alpha.Models.Person;

/**
 * FXML Controller class
 *
 * @author Amimi
 */
public class AuthController implements Initializable {

	SingletonConnection jdbc = SingletonConnection.getInstance();
	static Person person;
	// ***************************** //
	@FXML
	private TextField matricule_Input;
	@FXML
	private PasswordField password_Input;
	@FXML
	private ComboBox<Role> type_Selection;
	@FXML
	private Label error_Output;
	@FXML
	private Label matricule_Error;
	@FXML
	private Label password_Error;
	@FXML
	private Label type_Error;
	@FXML
	private BorderPane root_Pane;

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		// TODO

		// Populating The Type ComboBox From The Enum Interface
		type_Selection.setItems(FXCollections.observableArrayList(Role.values()));
	}

	@FXML
	private void handleLoginButton(ActionEvent event) throws SQLException {
		if (matricule_Input.getText().trim().isEmpty()) {
			matricule_Input.requestFocus();
			matricule_Error.setText("Matricule Is Required :( ");
		} else if (password_Input.getText().trim().isEmpty()) {
			password_Input.requestFocus();
			password_Error.setText("Password Is Required :( ");
		} else if (type_Selection.getValue() == null) {
			type_Error.setText("Please Select Your Type :( ");
		} else {
			// Process Of The Authentication Goes Here
			person = jdbc.sign_InPersonBasedOnHisType(matricule_Input.getText(), password_Input.getText(), type_Selection.getValue());
			if (person != null) {
				// code goes here 
				if (person.getRole().equals(Role.ADMINISTRATOR)) {
					// REDIRECTION ADMINISTRATOR BOARD
					System.out.println("Administrator Dashboard");
					loadTheSpecificBoard("Dashboard_Admin.fxml");
				} else if (person.getRole().equals(Role.STAFF)) {
					// REDIRECTION STAFF BOARD
					System.out.println("Staff Dashboard");
					loadTheSpecificBoard("Dashboard_Staff.fxml");
				} else {
					// REDIRECTION APPRENANT BOARD
					System.out.println("Apprenant Dashboard");
					loadTheSpecificBoard("Dashboard_Apprenant.fxml");
				}

			} else {
				System.out.println("No Person Was Found ::(( ");
				error_Output.setText("No Person Was Found");
			}
		}
	}

	private void loadTheSpecificBoard(String path) {
		try {
			root_Pane = FXMLLoader.load(getClass().getResource(path));
		} catch (IOException ex) {
			Logger.getLogger(AuthController.class.getName()).log(Level.SEVERE, null, ex);
		}
		Scene scene = new Scene(root_Pane);
		Skills_TreeVAlpha._Window_.setScene(scene);
		Skills_TreeVAlpha._Window_.show();
	}

}



























































