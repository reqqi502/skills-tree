/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha.Models.DBA;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import skills_tree.v.alpha.Models.Administrator;
import skills_tree.v.alpha.Models.Apprenant;
import skills_tree.v.alpha.Models.Competence;
import skills_tree.v.alpha.Models.Enums.Category;
import skills_tree.v.alpha.Models.Enums.Duration;
import skills_tree.v.alpha.Models.Enums.Role;
import skills_tree.v.alpha.Models.Enums.Sensitive;
import skills_tree.v.alpha.Models.Level;
import skills_tree.v.alpha.Models.Person;
import skills_tree.v.alpha.Models.Promotion;
import skills_tree.v.alpha.Models.Reference;
import skills_tree.v.alpha.Models.Staff;

/**
 *
 * @author Jamal-Jcyber
 */
public class SingletonConnection {

    // Step 1  
    // create a SingeltonConnection class.  
    // static member holds only one instance of the SingeltonConnection class.  
    private static SingletonConnection instance;

    // to get The DB Configuration Properties From The dbConfig File .Properties
    // private static ResourceBundle reader = null;
    // SingeltonConnection prevents the instantiation from any other class.
    private SingletonConnection() {
    }

    // Now we are providing gloabal point of access.
    public static SingletonConnection getInstance() {
        if (instance == null) {
            instance = new SingletonConnection();
        }
        return instance;
    }

    // to get the connection from methods like insert, view etc.  
    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/skills_tree", "root", "");
            System.out.println("Connection Established Successfully :) ");
        } catch (ClassNotFoundException exception) {
            System.out.println("Connection to database has a problem :( " + exception.getMessage());
        }
        return connection;
    }

    // PERSON OPERATIONS
    public LinkedList<Person> get_All_PersonsContents() throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        LinkedList<Person> _lists = new LinkedList<>();

        try {
            connection = SingletonConnection.getConnection();
            String query_GET = "SELECT * FROM `person`";
            statement = connection.prepareStatement(query_GET);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                if (resultSet.getObject(7).equals(Role.STAFF)) {
                    Person p = new Staff(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6), Role.valueOf(resultSet.getString(7)), resultSet.getInt(8));
                    _lists.add(p);
                } else if (resultSet.getObject(7).equals(Role.APPRENANT)) {
                    Person p = new Apprenant(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6), Role.valueOf(resultSet.getString(7)), resultSet.getInt(8));
                    _lists.add(p);
                } else {
                    Person p = new Administrator(resultSet.getString(5), resultSet.getString(6), Role.valueOf(resultSet.getString(7)));
                    _lists.add(p);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }
        return _lists;

    }

    public int sign_UpPersonMethod(Person p) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int state = 0;
        try {
            // check if the User Exists Or Not
            // code goes here :: 
            if (_isPersonExists(p.getEmail(), p.getMatricule())) {
                System.out.println("Person is Already Exists :( ");
            } else {
                connection = SingletonConnection.getConnection();
                String query_POST = "INSERT INTO person (`fullname`, `phone`, `email`, `matricule`, `password`, `role`, `id_Promotion`) VALUES (?, ?, ?, ?, ?, ?, ?)";
                statement = connection.prepareCall(query_POST);
                statement.setString(1, p.getFullname());
                statement.setString(2, p.getPhone());
                statement.setString(3, p.getEmail());
                statement.setString(4, p.getMatricule());
                statement.setString(5, p.getPassword());
                statement.setString(6, p.getRole().toString());
                statement.setInt(7, p.getId_Promotion());
                state = statement.executeUpdate();
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return state;
    }

    private boolean _isPersonExists(String email, String matricule) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        boolean exist = false;
        try {
            connection = SingletonConnection.getConnection();
            String query_CHECK = "SELECT * FROM person WHERE email=? OR matricule=?";
            statement = connection.prepareStatement(query_CHECK);
            statement.setString(1, email);
            statement.setString(2, matricule);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                if (resultSet.getString(4).equals(email)) {
                    System.out.println("Email Already Exists ");
                    exist = true;
                }
                if (resultSet.getString(5).equals(matricule)) {
                    System.out.println("Matricule Already Exists ");
                    exist = true;
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }
        return exist;
    }

    public Person sign_InPersonBasedOnHisType(String matricule, String password, Role role) throws SQLException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Person person = null;
        try {
            connection = SingletonConnection.getConnection();
            String query_Authentication = "SELECT * FROM person WHERE matricule=? AND password=? AND role=?";
            statement = connection.prepareStatement(query_Authentication);
            statement.setString(1, matricule);
            statement.setString(2, password);
            statement.setString(3, role.toString());
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                if (resultSet.getString(5).equals(matricule) && resultSet.getString(6).equals(password) && resultSet.getString(7).equals(role.toString())) {
                    if (resultSet.getString(7).equals("ADMINISTRATOR")) {
                        person = new Administrator(resultSet.getString(5), resultSet.getString(6), Role.valueOf(resultSet.getString(7)));
                    } else if (resultSet.getString(7).equals("STAFF")) {
                        person = new Staff(resultSet.getString(5), resultSet.getString(6), Role.valueOf(resultSet.getString(7)));
                    } else {
                        person = new Apprenant(resultSet.getString(5), resultSet.getString(6), Role.valueOf(resultSet.getString(7)));
                    }
                } else {
                    System.out.println("Username & Password & Role Incorrect :( ");
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }
        return person;
    }

    // END OF PERSON OPERATIONS
    // ===== ********** ===== 
    // ===== ********** ===== 
    // ===== ********** ===== 
    // PROMOTION OPERATIONS
    public LinkedList<Promotion> get_All_PromotionsContents() throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        LinkedList<Promotion> _listsPromotions = new LinkedList<>();
        try {
            connection = SingletonConnection.getConnection();
            String query_GET = "SELECT * FROM `promotion`";
            statement = connection.prepareStatement(query_GET);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Promotion promotion = new Promotion(resultSet.getInt(1), resultSet.getString(2), resultSet.getDate(3).toLocalDate(), Category.valueOf(resultSet.getString(4)), resultSet.getString(5));
                _listsPromotions.add(promotion);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }
        return _listsPromotions;
    }

    public int create_NewPromotion(Promotion p) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int state = 0;
        try {
            // check if the User Exists Or Not
            // code goes here :: 
            if (_isPromotionExists(p.getTitle())) {
                System.out.println("Promotion is Already Exists :( ");
            } else {
                connection = SingletonConnection.getConnection();
                String query_POST = "INSERT INTO promotion (`title`, `date_Creation`, `category`, `description`) VALUES (?, ?, ?, ?)";
                statement = connection.prepareStatement(query_POST);
                statement.setString(1, p.getTitle());
                statement.setDate(2, java.sql.Date.valueOf(p.getDate_Creation()));
                statement.setString(3, p.getCategory_OfPromotion().toString());
                statement.setString(4, p.getDescription());

                state = statement.executeUpdate();
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return state;
    }

    private boolean _isPromotionExists(String title) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        boolean exist = false;
        try {
            connection = SingletonConnection.getConnection();
            String query_CHECK = "SELECT * FROM promotion WHERE title=?";
            statement = connection.prepareStatement(query_CHECK);
            statement.setString(1, title);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                if (resultSet.getString(2).equals(title)) {
                    System.out.println(" Promotion Title Already Exists ");
                    exist = true;
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }
        return exist;
    }

    public int update_Promotion(Promotion p) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int state = 0;
        try {
            if (_isExistsByID(p.getId_Promotion())) {
                connection = SingletonConnection.getConnection();
                String query_PUT = "UPDATE `promotion` SET `title`=?, `date_Creation`=?, `category`=?, `description`=? WHERE id_Promotion=" + p.getId_Promotion();
                statement = connection.prepareStatement(query_PUT);
                statement.setString(1, p.getTitle());
                statement.setDate(2, java.sql.Date.valueOf(p.getDate_Creation()));
                statement.setString(3, p.getCategory_OfPromotion().toString());
                statement.setString(4, p.getDescription());
                state = statement.executeUpdate();
            } else {
                System.out.println("!= existby id");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return state;
    }

    private boolean _isExistsByID(long id_Promotion) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
//        ResultSet resultSet = null;
        boolean exists = false;
        try {
            connection = SingletonConnection.getConnection();
            String query_CheckById = "SELECT * FROM `promotion` WHERE id_Promotion=" + id_Promotion;
            statement = connection.prepareStatement(query_CheckById);
//            resultSet = statement.executeQuery();
//            if (resultSet.next()) {
////                Promotion promotion = new Promotion(resultSet.getInt(1), resultSet.getString(2), resultSet.getDate(3).toLocalDate(), Category.valueOf(resultSet.getString(4)), resultSet.getString(5));
//                exists = true;
//            }
            exists = statement.execute();
        } catch (Exception e) {

        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
//            if (resultSet != null) {
//                resultSet.close();
//            }
        }

        return exists;
    }

    public Promotion _getOneByID(long id_Promotion) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Promotion promo = null;
        try {
            connection = SingletonConnection.getConnection();
            String query_CheckById = "SELECT * FROM promotion WHERE id_Promotion=" + id_Promotion;
            statement = connection.prepareStatement(query_CheckById);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                promo = new Promotion(resultSet.getInt(1), resultSet.getString(2), resultSet.getDate(3).toLocalDate(), Category.valueOf(resultSet.getString(4)), resultSet.getString(5));
                System.out.println(promo.toString());
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }

        return promo;
    }

    public int delete_OneSpecificPromotion(int id) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int state = 0;

        try {
            connection = SingletonConnection.getConnection();
            String query_DELETE = "DELETE FROM `promotion` WHERE id_Promotion=?";
            statement = connection.prepareStatement(query_DELETE);
            statement.setInt(1, id);
            state = statement.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return state;
    }

    // END OF PROMOTION OPERATIONS
    // ===== ********** ===== 
    // ===== ********** ===== 
    // ===== ********** ===== 
    // REFERENCIAL OPERATIONS
    public LinkedList<Reference> get_All_ReferencesContents() throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        LinkedList<Reference> _listsReferences = new LinkedList<>();
        try {
            connection = SingletonConnection.getConnection();
            String query_GET = "SELECT * FROM `referencial`";
            statement = connection.prepareStatement(query_GET);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Reference reference = new Reference(resultSet.getInt(1), resultSet.getString(2), resultSet.getInt(3), Duration.valueOf(resultSet.getString(4)), resultSet.getBoolean(5));
                _listsReferences.add(reference);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }
        return _listsReferences;
    }

    public int create_Referencial(Reference r) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int state = 0;
        try {
            // check if the User Exists Or Not
            // code goes here :: 
            if (_isReferencialExists(r.getTitle())) {
                System.out.println("Referencial is Already Exists :( ");
            } else {
                connection = SingletonConnection.getConnection();
                String query_POST = "INSERT INTO referencial (`title`, `promo_Id`, `duration`, `status`) VALUES (?, ?, ?, ?)";
                statement = connection.prepareStatement(query_POST);
                statement.setString(1, r.getTitle());
                statement.setInt(2, r.getPromo_Id());
                statement.setString(3, r.getDuration().toString());
                statement.setBoolean(4, false);

                state = statement.executeUpdate();
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return state;
    }

    public int update_Referencial(Reference r) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int state = 0;
        try {
            if (_isReferencialExistsByID(r.getId_Reference())) {
                connection = SingletonConnection.getConnection();
                String query_PUT = "UPDATE `referencial` SET `title`=?,`promo_Id`=?,`duration`=?,`status`=? WHERE id_Reference=" + r.getId_Reference();
                statement = connection.prepareStatement(query_PUT);
                statement.setString(1, r.getTitle());
                statement.setInt(2, r.getPromo_Id());
                statement.setString(3, r.getDuration().toString());
                statement.setBoolean(4, r.isStatus());
                state = statement.executeUpdate();
            } else {
                System.out.println("!= existby id");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return state;
    }

    private boolean _isReferencialExistsByID(long id_Referencial) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        boolean exists = false;
        try {
            connection = SingletonConnection.getConnection();
            String query_CheckById = "SELECT * FROM `referencial` WHERE id_Reference=" + id_Referencial;
            statement = connection.prepareStatement(query_CheckById);
            exists = statement.execute();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }

        return exists;
    }

    private boolean _isReferencialExists(String title) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        boolean exist = false;
        try {
            connection = SingletonConnection.getConnection();
            String query_CHECK = "SELECT * FROM referencial WHERE title=?";
            statement = connection.prepareStatement(query_CHECK);
            statement.setString(1, title);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                if (resultSet.getString(2).equals(title)) {
                    System.out.println(" Referencial Title Already Exists ");
                    exist = true;
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }
        return exist;
    }

    public Reference _getOneReferenceByID(long id_Reference) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Reference reference = null;
        try {
            connection = SingletonConnection.getConnection();
            String query_CheckById = "SELECT * FROM referencial WHERE id_Reference=" + id_Reference;
            statement = connection.prepareStatement(query_CheckById);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                reference = new Reference(resultSet.getInt(1), resultSet.getString(2), resultSet.getInt(3), Duration.valueOf(resultSet.getString(4)), resultSet.getBoolean(5));
                System.out.println(reference.toString());
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }

        return reference;
    }

    public int delete_OneSpecificReference(int id) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int state = 0;

        try {
            connection = SingletonConnection.getConnection();
            String query_DELETE = "DELETE FROM `referencial` WHERE id_Reference=?";
            statement = connection.prepareStatement(query_DELETE);
            statement.setInt(1, id);
            state = statement.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return state;
    }

    // public int validate_TheTargetReferencial() throws SQLException{}
    // REFERENCIAL OPERATIONS
    // ===== ********** ===== 
    // ===== ********** ===== 
    // ===== ********** ===== 
    // COMPETENCE OPERATIONS
    public LinkedList<Competence> get_All_CompetencesContents() throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        LinkedList<Competence> _listsCompetences = new LinkedList<>();
        try {
            connection = SingletonConnection.getConnection();
            String query_GET = "SELECT * FROM `referencial`";
            statement = connection.prepareStatement(query_GET);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Competence competence = new Competence(resultSet.getInt(1), resultSet.getInt(2), resultSet.getBoolean(3), resultSet.getString(4));
                _listsCompetences.add(competence);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }
        return _listsCompetences;
    }

    public int create_Competence(Competence c) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int state = 0;
        try {
            // check if the User Exists Or Not
            // code goes here :: 
            if (_isCompetenceExists(c.getTitle())) {
                System.out.println("Competence is Already Exists :( ");
            } else {
                connection = SingletonConnection.getConnection();
                String query_POST = "INSERT INTO competence (`referencial_Id`, `status`, `title`) VALUES (?, ?, ?)";
                statement = connection.prepareStatement(query_POST);
                statement.setInt(1, c.getReferencial_Id());
                statement.setBoolean(2, Boolean.FALSE);
                statement.setString(3, c.getTitle());

                state = statement.executeUpdate();
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return state;
    }

    private boolean _isCompetenceExists(String title) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        boolean exist = false;
        try {
            connection = SingletonConnection.getConnection();
            String query_CHECK = "SELECT * FROM competence WHERE title=?";
            statement = connection.prepareStatement(query_CHECK);
            statement.setString(1, title);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                if (resultSet.getString(4).equals(title)) {
                    System.out.println(" Competence Title Already Exists ");
                    exist = true;
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }
        return exist;
    }

    public int update_Competence(Competence c) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int state = 0;
        try {
            if (_isCompetenceExistsByID(c.getId_Competence())) {
                connection = SingletonConnection.getConnection();
                String query_PUT = "UPDATE `competence` SET `referencial_Id`=?,`status`=?,`title`=? WHERE id_Competence=" + c.getId_Competence();
                statement = connection.prepareStatement(query_PUT);
                statement.setInt(1, c.getReferencial_Id());
                statement.setBoolean(2, c.isStatus());
                statement.setString(3, c.getTitle());
                state = statement.executeUpdate();
            } else {
                System.out.println("!= existby id");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return state;
    }

    private boolean _isCompetenceExistsByID(long id_Competence) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        boolean exists = false;
        try {
            connection = SingletonConnection.getConnection();
            String query_CheckById = "SELECT * FROM `competence` WHERE id_Competence=" + id_Competence;
            statement = connection.prepareStatement(query_CheckById);
            exists = statement.execute();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return exists;
    }

    public Competence _getOneCompetenceByID(long id_Competence) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Competence competence = null;
        try {
            connection = SingletonConnection.getConnection();
            String query_CheckById = "SELECT * FROM competence WHERE id_Competence=" + id_Competence;
            statement = connection.prepareStatement(query_CheckById);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                competence = new Competence(resultSet.getInt(1), resultSet.getInt(2), resultSet.getBoolean(3), resultSet.getString(4));
                System.out.println(competence.toString());
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }

        return competence;
    }

    public int delete_OneSpecificCompetence(int id) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int state = 0;

        try {
            connection = SingletonConnection.getConnection();
            String query_DELETE = "DELETE FROM `competence` WHERE id_Competence=?";
            statement = connection.prepareStatement(query_DELETE);
            statement.setInt(1, id);
            state = statement.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return state;
    }

    // public int validate_TheTargetCompetence() throws SQLException{}
    // COMPETENCE OPERATIONS
    // ===== ********** ===== 
    // ===== ********** ===== 
    // ===== ********** ===== 
    // LEVELS OPERATIONS
    public int create_CustomCompetenceWithLevels(Level l) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int state = 0;
        try {
            // check if the User Exists Or Not
            // code goes here :: 
//            if (isRepeated(l.getCompetence_Id(), l.getSensitive())) {
//                System.out.println("Competence With The Level is Already Exists :( ");
//            } else {
            connection = SingletonConnection.getConnection();
            String query_POST = "INSERT INTO level (`competence_Id`, `sensitive`, `visibility`, `level_One`, `level_Two`, `level_Three`, `approved`) VALUES (?, ?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(query_POST);
            statement.setInt(1, l.getCompetence_Id());
            statement.setString(2, l.getSensitive().toString());
            statement.setBoolean(3, true);
            statement.setBoolean(4, false);
            statement.setBoolean(5, false);
            statement.setBoolean(6, false);
            statement.setBoolean(7, false);

            state = statement.executeUpdate();
//            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return state;
    }
    // LEVELS OPERATIONS

    private boolean isRepeated(int id_Competence, Sensitive sensitive) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        boolean exist = false;
        try {
            connection = SingletonConnection.getConnection();
            String query_CHECK = "SELECT COUNT (competence_Id, sensitive ) AS Validation FROM level WHERE competence_Id=? AND sensitive=?";
            statement = connection.prepareStatement(query_CHECK);
            statement.setInt(1, id_Competence);
            statement.setObject(2, sensitive);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                if (resultSet.getInt(2) == id_Competence && resultSet.getObject(3, Sensitive.class).equals(sensitive)) {
                    System.out.println(" Competence Title Already Exists ");
                    exist = true;
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        }
        return exist;
    }

}











































































































