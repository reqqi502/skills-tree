/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha.Models;

import skills_tree.v.alpha.Models.Enums.Sensitive;

/**
 *
 * @author Jamal-Jcyber
 */
public class Level {

    private long id_Level;
    private int competence_Id;
    private Sensitive sensitive;
    private boolean visibility;
    private boolean level_One;
    private boolean level_Two;
    private boolean level_Three;

    private boolean approved;

    public Level(int competence_Id, Sensitive sensitive, boolean visibility, boolean level_One, boolean level_Two, boolean level_Three, boolean approved) {
        this.competence_Id = competence_Id;
        this.sensitive = sensitive;
        this.visibility = visibility;
        this.level_One = level_One;
        this.level_Two = level_Two;
        this.level_Three = level_Three;
        this.approved = approved;
    }

    public Level(long id_Level, int competence_Id, Sensitive sensitive, boolean visibility, boolean approved) {
        this.id_Level = id_Level;
        this.competence_Id = competence_Id;
        this.sensitive = sensitive;
        this.visibility = visibility;
        this.approved = approved;
    }

    public long getId_Level() {
        return id_Level;
    }

    public void setId_Level(long id_Level) {
        this.id_Level = id_Level;
    }

    public int getCompetence_Id() {
        return competence_Id;
    }

    public void setCompetence_Id(int competence_Id) {
        this.competence_Id = competence_Id;
    }

    public Sensitive getSensitive() {
        return sensitive;
    }

    public void setSensitive(Sensitive sensitive) {
        this.sensitive = sensitive;
    }

    public boolean isVisibility() {
        return visibility;
    }

    public void setVisibility(boolean visibility) {
        this.visibility = visibility;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    public boolean isLevel_One() {
        return level_One;
    }

    public void setLevel_One(boolean level_One) {
        this.level_One = level_One;
    }

    public boolean isLevel_Two() {
        return level_Two;
    }

    public void setLevel_Two(boolean level_Two) {
        this.level_Two = level_Two;
    }

    public boolean isLevel_Three() {
        return level_Three;
    }

    public void setLevel_Three(boolean level_Three) {
        this.level_Three = level_Three;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Level{id_Level=").append(id_Level);
        sb.append(", competence_Id=").append(competence_Id);
        sb.append(", sensitive=").append(sensitive);
        sb.append(", visibility=").append(visibility);
        sb.append(", level_One=").append(level_One);
        sb.append(", level_Two=").append(level_Two);
        sb.append(", level_Three=").append(level_Three);
        sb.append(", approved=").append(approved);
        sb.append('}');
        return sb.toString();
    }

}
