/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha.Models;

import skills_tree.v.alpha.Models.Enums.Sensitive;

/**
 *
 * @author Jamal-Jcyber
 */
public class Competence {

    private long id_Competence;
    private int referencial_Id;
    private boolean status;
    private String title;
   
    public Competence(long id_Competence, int referencial_Id, boolean status, String title) {
        this.id_Competence = id_Competence;
        this.referencial_Id = referencial_Id;
        this.status = status;
        this.title = title;
      
    }

    public Competence(int referencial_Id, boolean status, String title) {
        this.referencial_Id = referencial_Id;
        this.status = status;
        this.title = title;
       
    }

    public long getId_Competence() {
        return id_Competence;
    }

    public void setId_Competence(long id_Competence) {
        this.id_Competence = id_Competence;
    }

    public int getReferencial_Id() {
        return referencial_Id;
    }

    public void setReferencial_Id(int referencial_Id) {
        this.referencial_Id = referencial_Id;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Competence{id_Competence=").append(id_Competence);
        sb.append(", referencial_Id=").append(referencial_Id);
        sb.append(", status=").append(status);
        sb.append(", title=").append(title);
        sb.append('}');
        return sb.toString();
    }

}
