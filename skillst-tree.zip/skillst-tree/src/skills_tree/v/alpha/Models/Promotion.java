/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha.Models;

import java.time.LocalDate;
import skills_tree.v.alpha.Models.Enums.Category;

/**
 *
 * @author Jamal-Jcyber
 */
public class Promotion {

    private long id_Promotion;
    private String title;
    private LocalDate date_Creation;
    private Category category_OfPromotion;
    private String description;

    public Promotion(String title, LocalDate date_Creation, Category category_OfPromotion, String description) {
        this.title = title;
        this.date_Creation = date_Creation;
        this.category_OfPromotion = category_OfPromotion;
        this.description = description;
    }

    public Promotion(long id_Promotion, String title, LocalDate date_Creation, Category category_OfPromotion, String description) {
        this.id_Promotion = id_Promotion;
        this.title = title;
        this.date_Creation = date_Creation;
        this.category_OfPromotion = category_OfPromotion;
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getId_Promotion() {
        return id_Promotion;
    }

    public void setId_Promotion(long id_Promotion) {
        this.id_Promotion = id_Promotion;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public LocalDate getDate_Creation() {
        return date_Creation;
    }

    public void setDate_Creation(LocalDate date_Creation) {
        this.date_Creation = date_Creation;
    }

    public Category getCategory_OfPromotion() {
        return category_OfPromotion;
    }

    public void setCategory_OfPromotion(Category category_OfPromotion) {
        this.category_OfPromotion = category_OfPromotion;
    }

    @Override
    public String toString() {
        return "Promotion{" + "id_Promotion=" + id_Promotion + ", title=" + title + ", date_Creation=" + date_Creation + ", category_OfPromotion=" + category_OfPromotion + ", description=" + description + '}';
    }

}
