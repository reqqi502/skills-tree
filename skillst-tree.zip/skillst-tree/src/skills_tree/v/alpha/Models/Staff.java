/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha.Models;

import skills_tree.v.alpha.Models.Enums.Role;

/**
 *
 * @author Jamal-Jcyber
 */
public class Staff extends Person {

    public Staff(String matricule, String password, Role role) {
        super(matricule, password, role);
    }

    public Staff(String fullname, String phone, String email, String matricule, String password, Role role, int id_Promotion) {
        super(fullname, phone, email, matricule, password, role, id_Promotion);
    }

    public Staff(long id_Person, String fullname, String phone, String email, String matricule, String password, Role role, int id_Promotion) {
        super(id_Person, fullname, phone, email, matricule, password, role, id_Promotion);
    }
    
    

    @Override
    public String display_Infos() {
        return super.toString();
    }

}
