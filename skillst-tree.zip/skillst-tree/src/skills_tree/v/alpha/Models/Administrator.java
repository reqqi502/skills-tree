/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha.Models;

import skills_tree.v.alpha.Models.Enums.Role;

/**
 *
 * @author Jamal-Jcyber
 */
public class Administrator extends Person {

    public Administrator(String matricule, String password, Role role) {
        super(matricule, password, role);
    }

    @Override
    public String display_Infos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
