/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha.Models;

import skills_tree.v.alpha.Models.Enums.Duration;

/**
 *
 * @author Jamal-Jcyber
 */
public class Reference {

    private long id_Reference;
    private String title;
    private int promo_Id;
    private Duration duration;
    private boolean status;

    public Reference(String title, int promo_Id, Duration duration, boolean status) {
        this.title = title;
        this.promo_Id = promo_Id;
        this.duration = duration;
        this.status = status;
    }

    public Reference(long id_Reference, String title, int promo_Id, Duration duration, boolean status) {
        this.id_Reference = id_Reference;
        this.title = title;
        this.promo_Id = promo_Id;
        this.duration = duration;
        this.status = status;
    }

    public long getId_Reference() {
        return id_Reference;
    }

    public void setId_Reference(long id_Reference) {
        this.id_Reference = id_Reference;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPromo_Id() {
        return promo_Id;
    }

    public void setPromo_Id(int promo_Id) {
        this.promo_Id = promo_Id;
    }

    public Duration getDuration() {
        return duration;
    }

    public void setDuration(Duration duration) {
        this.duration = duration;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Reference{id_Reference=").append(id_Reference);
        sb.append(", title=").append(title);
        sb.append(", promo_Id=").append(promo_Id);
        sb.append(", duration=").append(duration);
        sb.append(", status=").append(status);
        sb.append('}');
        return sb.toString();
    }

}
