/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha.Models;

import java.util.Objects;
import java.util.logging.Logger;
import skills_tree.v.alpha.Models.Enums.Role;

/**
 *
 * @author Jamal-Jcyber
 */
public abstract class Person {

    private long id_Person;
    private String fullname;
    private String phone;
    private String email;
    private String matricule;
    private String password;
    private Role role;
    private int id_Promotion;

    public Person(String fullname, String phone, String email, String matricule, String password, Role role, int id_Promotion) {
        this.fullname = fullname;
        this.phone = phone;
        this.email = email;
        this.matricule = matricule;
        this.password = password;
        this.role = role;
        this.id_Promotion = id_Promotion;
    }

    public Person(long id_Person, String fullname, String phone, String email, String matricule, String password, Role role, int id_Promotion) {
        this.id_Person = id_Person;
        this.fullname = fullname;
        this.phone = phone;
        this.email = email;
        this.matricule = matricule;
        this.password = password;
        this.role = role;
        this.id_Promotion = id_Promotion;
    }

    public Person(String matricule, String password, Role role) {
        this.matricule = matricule;
        this.password = password;
        this.role = role;
    }

    public long getId_Person() {
        return id_Person;
    }

    public void setId_Person(long id_Person) {
        this.id_Person = id_Person;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public int getId_Promotion() {
        return id_Promotion;
    }

    public void setId_Promotion(int id_Promotion) {
        this.id_Promotion = id_Promotion;
    }
    
    

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Person{id_Person=").append(id_Person);
        sb.append(", fullname=").append(fullname);
        sb.append(", phone=").append(phone);
        sb.append(", email=").append(email);
        sb.append(", matricule=").append(matricule);
        sb.append(", password=").append(password);
        sb.append(", role=").append(role);
        sb.append(", id_Promotion=").append(id_Promotion);
        sb.append('}');
        return sb.toString();
    }

    public abstract String display_Infos();

}




