/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha;

import java.net.URL;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import skills_tree.v.alpha.Models.DBA.SingletonConnection;
import skills_tree.v.alpha.Models.Person;

/**
 * FXML Controller class
 *
 * @author Amimi
 */
public class Dashboard_StaffController implements Initializable {

	LinkedList<Person> _listsApprenants;
	SingletonConnection jdbc = SingletonConnection.getInstance();

	private Label current_User;
	@FXML
	private TableView<Person> _AllApprenantsLists;

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		// TODO
		current_User.setText("Welcome Back " + AuthController.person.getMatricule());

		try {
			_listsApprenants = jdbc.get_All_PersonsContents();

		} catch (SQLException ex) {
			Logger.getLogger(Dashboard_StaffController.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

}









