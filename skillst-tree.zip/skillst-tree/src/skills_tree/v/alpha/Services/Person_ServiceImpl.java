/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package skills_tree.v.alpha.Services;

import skills_tree.v.alpha.Repositories.Person_Repoeitory;

/**
 *
 * @author Jamal-Jcyber
 */
public class Person_ServiceImpl implements Person_Repoeitory {

}

